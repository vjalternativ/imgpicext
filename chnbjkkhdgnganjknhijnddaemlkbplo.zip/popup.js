$("body").append('<script src="https://imgpic.org/webapp/js/jquery-3.0.0.min.js" ></script>');
$("body").append('<script src="https://imgpic.org/webapp/js/bootstrap.min.js"></script>');
$("body").append('<script>var base_url ="https://imgpic.org/";</script>');
$("body").append('<script src="https://imgpic.org/webapp/js/feeds.js"></script>');
$("body").append('<div id="imgpicmodal"></div>');
$("body").append('<script type="text/javascript" >'+
'function showboardmodal(src,e){'+
'e.preventDefault();'+
'$.ajaxSetup({ crossDomain: true,xhrFields: { withCredentials: true}});'+
'$("#imgpicsavebtn").remove();var url = "https://imgpic.org/ip_user/ajaxAddToBoardModal";'+
				'$.post(url,{},function(result){'+
				'$("#imgpicmodal").html(result);webtitle = $(location).attr("href"); pinimage(src,webtitle);'+
				'});}</script>');


$("img").hover(function(e){
						//e.preventDefault();
						var src = this.src;
	$(".imgpicsavebtn").remove();
    $(this).parent().attr("href","javascript:");
	var html = '<span id="imgpicsavebtn" class="imgpicsavebtn" style="position:absolute;z-index:8975309;width:auto;padding:10px;color:#fff;border:1px solid rgb(128,128,128);border-radius:4px;margin:6px;background-color:#0084b4;cursor:pointer;" onclick="showboardmodal(\''+src+'\',event);return false;">Save</span>';
	$(this).before(html);
});


$(".imgpicsavebtn").hover(function(){						
	}, function(){
	$(".imgpicsavebtn").remove();
});


